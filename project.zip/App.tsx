import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Button } from './components/ui/button';
import { Moon, Sun, Rocket, MessageCircle, Globe, Brain, Home, BookOpen } from 'lucide-react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AstroBuddyChat } from './components/AstroBuddyChat';
import { SpaceDataDashboard } from './components/SpaceDataDashboard';
import { SolarSystem3D } from './components/SolarSystem3D';
import { SpaceQuiz } from './components/SpaceQuiz';
import { SpaceExplorer } from './components/SpaceExplorer';
import { Footer } from './components/Footer';

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [activeTab, setActiveTab] = useState('home');

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-slate-900/40 to-slate-900"></div>
      
      <div className="relative z-10">
        <Header isDarkMode={isDarkMode} toggleTheme={toggleTheme} />
        
        <main className="container mx-auto px-4 py-8">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-6 bg-slate-800/50 backdrop-blur-sm border border-slate-700">
              <TabsTrigger value="home" className="data-[state=active]:bg-purple-600">
                <Home className="w-4 h-4 mr-2" />
                Home
              </TabsTrigger>
              <TabsTrigger value="explorer" className="data-[state=active]:bg-purple-600">
                <BookOpen className="w-4 h-4 mr-2" />
                Explorer
              </TabsTrigger>
              <TabsTrigger value="chat" className="data-[state=active]:bg-purple-600">
                <MessageCircle className="w-4 h-4 mr-2" />
                AstroBuddy
              </TabsTrigger>
              <TabsTrigger value="data" className="data-[state=active]:bg-purple-600">
                <Rocket className="w-4 h-4 mr-2" />
                Live Data
              </TabsTrigger>
              <TabsTrigger value="solar" className="data-[state=active]:bg-purple-600">
                <Globe className="w-4 h-4 mr-2" />
                Solar System
              </TabsTrigger>
              <TabsTrigger value="quiz" className="data-[state=active]:bg-purple-600">
                <Brain className="w-4 h-4 mr-2" />
                Space Quiz
              </TabsTrigger>
            </TabsList>

            <TabsContent value="home" className="mt-8">
              <Hero setActiveTab={setActiveTab} />
            </TabsContent>

            <TabsContent value="explorer" className="mt-8">
              <SpaceExplorer />
            </TabsContent>

            <TabsContent value="chat" className="mt-8">
              <AstroBuddyChat />
            </TabsContent>

            <TabsContent value="data" className="mt-8">
              <SpaceDataDashboard />
            </TabsContent>

            <TabsContent value="solar" className="mt-8">
              <SolarSystem3D />
            </TabsContent>

            <TabsContent value="quiz" className="mt-8">
              <SpaceQuiz />
            </TabsContent>
          </Tabs>
        </main>

        <Footer />
      </div>
    </div>
  );
}
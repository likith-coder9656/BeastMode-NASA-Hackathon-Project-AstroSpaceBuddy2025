import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';

const app = new Hono();

// Enable CORS for all routes
app.use('*', cors({
  origin: '*',
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}));

// Enable logging
app.use('*', logger(console.log));

// NASA API endpoints
app.get('/make-server-8f12e3f9/nasa/apod', async (c) => {
  try {
    const apiKey = 'QnnTjHHwCZ5D3YmslB2kE10n5PiaMioKUH3GiKg2';
    const response = await fetch(`https://api.nasa.gov/planetary/apod?api_key=${apiKey}`);
    
    if (!response.ok) {
      throw new Error(`NASA APOD API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    return c.json({
      success: true,
      data: data
    });
  } catch (error) {
    console.error('Error fetching APOD data:', error);
    return c.json({
      success: false,
      error: `Failed to fetch Astronomy Picture of the Day: ${error.message}`
    }, 500);
  }
});

app.get('/make-server-8f12e3f9/nasa/neo', async (c) => {
  try {
    const apiKey = 'QnnTjHHwCZ5D3YmslB2kE10n5PiaMioKUH3GiKg2';
    const today = new Date().toISOString().split('T')[0];
    const weekLater = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    const response = await fetch(
      `https://api.nasa.gov/neo/rest/v1/feed?start_date=${today}&end_date=${weekLater}&api_key=${apiKey}`
    );
    
    if (!response.ok) {
      throw new Error(`NASA NEO API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    return c.json({
      success: true,
      data: data
    });
  } catch (error) {
    console.error('Error fetching NEO data:', error);
    return c.json({
      success: false,
      error: `Failed to fetch Near Earth Objects data: ${error.message}`
    }, 500);
  }
});

app.get('/make-server-8f12e3f9/iss/location', async (c) => {
  try {
    const response = await fetch('http://api.open-notify.org/iss-now.json');
    
    if (!response.ok) {
      throw new Error(`ISS API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    return c.json({
      success: true,
      data: {
        latitude: parseFloat(data.iss_position.latitude),
        longitude: parseFloat(data.iss_position.longitude),
        timestamp: data.timestamp
      }
    });
  } catch (error) {
    console.error('Error fetching ISS location:', error);
    return c.json({
      success: false,
      error: `Failed to fetch ISS location: ${error.message}`
    }, 500);
  }
});

// Mock Mars weather endpoint (since Mars weather API might be unavailable)
app.get('/make-server-8f12e3f9/mars/weather', async (c) => {
  try {
    // Generate mock Mars weather data
    const mockData = {
      sol: Math.floor(Math.random() * 1000) + 3500,
      temperature: {
        high: Math.floor(Math.random() * 20) - 30,
        low: Math.floor(Math.random() * 30) - 90
      },
      pressure: Math.floor(Math.random() * 200) + 650,
      wind_speed: Math.random() * 10 + 2,
      season: 'Northern Winter'
    };
    
    return c.json({
      success: true,
      data: mockData
    });
  } catch (error) {
    console.error('Error generating Mars weather data:', error);
    return c.json({
      success: false,
      error: `Failed to fetch Mars weather data: ${error.message}`
    }, 500);
  }
});

// Health check endpoint
app.get('/make-server-8f12e3f9/health', (c) => {
  return c.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    services: {
      nasa_apod: 'available',
      nasa_neo: 'available',
      iss_location: 'available',
      mars_weather: 'mock_data'
    }
  });
});

// Default route
app.get('/make-server-8f12e3f9/', (c) => {
  return c.json({
    message: 'AstroBuddy API Server',
    version: '1.0.0',
    endpoints: [
      '/nasa/apod - Astronomy Picture of the Day',
      '/nasa/neo - Near Earth Objects',
      '/iss/location - International Space Station location',
      '/mars/weather - Mars weather data',
      '/health - Server health check'
    ]
  });
});

// Start the server
Deno.serve(app.fetch);
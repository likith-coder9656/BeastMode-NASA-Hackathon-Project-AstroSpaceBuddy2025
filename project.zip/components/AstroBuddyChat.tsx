import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ScrollArea } from './ui/scroll-area';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Send, Bot, User, Sparkles } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

export function AstroBuddyChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "🚀 Hello! I'm AstroBuddy, your AI space companion created by Team BeastMode! I can help you explore the cosmos with real-time NASA data, answer space questions, and share fascinating facts about our universe. Developer Likith built me to make space exploration accessible and engaging. What would you like to know about space today?",
      sender: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response with space-related content
    setTimeout(() => {
      const aiResponse = generateAIResponse(userMessage.content);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        sender: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes('mars') || input.includes('red planet')) {
      return "🔴 Mars is fascinating! Currently, Mars has an average temperature of -80°F (-62°C) and experiences dust storms that can last for months. The latest NASA data shows that Mars has a very thin atmosphere, mostly CO2. Did you know that a day on Mars is 24 hours and 37 minutes? Would you like to know more about current Mars missions or weather data?";
    }
    
    if (input.includes('iss') || input.includes('space station')) {
      return "🛰️ The International Space Station (ISS) orbits Earth at approximately 408 km altitude and travels at 27,600 km/h! It completes an orbit around Earth every 90 minutes. The ISS is currently home to astronauts conducting various experiments. Would you like me to show you the ISS's current location?";
    }
    
    if (input.includes('asteroid') || input.includes('near earth')) {
      return "☄️ Asteroids are fascinating space rocks! NASA tracks Near-Earth Objects (NEOs) daily. Currently, there are over 28,000 known near-Earth asteroids. Most are harmless and burn up in our atmosphere as meteors. The largest asteroid, Ceres, is actually classified as a dwarf planet! Want to know about current asteroid approaches?";
    }
    
    if (input.includes('sun') || input.includes('solar')) {
      return "☀️ Our Sun is an incredible star! It's a massive ball of hot plasma that generates energy through nuclear fusion. The Sun's core temperature reaches 15 million°C, and it converts 600 million tons of hydrogen into helium every second! Solar activity affects space weather and can create beautiful auroras on Earth.";
    }
    
    if (input.includes('planet') || input.includes('solar system')) {
      return "🪐 Our solar system has 8 planets, each unique! Mercury is closest to the Sun, Venus is the hottest, Earth supports life, Mars is the red planet, Jupiter is the largest, Saturn has beautiful rings, Uranus rotates on its side, and Neptune is the windiest. Which planet interests you most?";
    }
    
    if (input.includes('apod') || input.includes('picture') || input.includes('photo')) {
      return "📸 NASA's Astronomy Picture of the Day (APOD) showcases stunning space imagery daily! Today's featured image could be anything from distant galaxies to nebulae, planets, or space missions. These images help us appreciate the beauty and scale of our universe. Would you like me to fetch today's space picture?";
    }

    // Default responses for general queries
    const defaultResponses = [
      "🌌 That's a great space question! The universe is full of mysteries waiting to be explored. From black holes to exoplanets, there's always something fascinating to discover. What specific aspect of space interests you most?",
      "🚀 Space exploration has taught us so much about our place in the universe! NASA and other space agencies are constantly making new discoveries. Is there a particular space mission or celestial body you'd like to learn about?",
      "⭐ The cosmos is incredibly vast - our observable universe contains over 2 trillion galaxies! Each galaxy has billions of stars, and many of those stars have planets. What would you like to explore in this infinite expanse?",
      "🛸 Space science is advancing rapidly! We're discovering new exoplanets, studying dark matter, and preparing for missions to Mars and beyond. What space topic can I help you explore today?"
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="max-w-4xl mx-auto bg-slate-800/50 border-slate-700 h-[600px] flex flex-col">
      <CardHeader className="border-b border-slate-700">
        <CardTitle className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl text-white">AstroBuddy AI</h2>
            <p className="text-sm text-slate-400">Powered by NASA data & Team BeastMode innovation</p>
          </div>
          <div className="ml-auto">
            <div className="flex items-center space-x-1 text-green-400">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm">Online</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start space-x-3 ${
                  message.sender === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {message.sender === 'assistant' && (
                  <Avatar className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600">
                    <AvatarFallback>
                      <Bot className="w-4 h-4 text-white" />
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div
                  className={`max-w-[70%] p-3 rounded-2xl ${
                    message.sender === 'user'
                      ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
                      : 'bg-slate-700 text-slate-100'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </div>

                {message.sender === 'user' && (
                  <Avatar className="w-8 h-8 bg-slate-600">
                    <AvatarFallback>
                      <User className="w-4 h-4 text-white" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            
            {isTyping && (
              <div className="flex items-start space-x-3">
                <Avatar className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600">
                  <AvatarFallback>
                    <Bot className="w-4 h-4 text-white" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-slate-700 p-3 rounded-2xl">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="border-t border-slate-700 p-4">
          <div className="flex space-x-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask AstroBuddy about space, planets, NASA missions..."
              className="flex-1 bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:ring-purple-500 focus:border-purple-500"
              disabled={isTyping}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isTyping}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-3">
            {['Tell me about Mars', 'Where is the ISS?', 'Show me today\'s space photo', 'What are asteroids?'].map((suggestion) => (
              <Button
                key={suggestion}
                variant="outline"
                size="sm"
                onClick={() => setInputValue(suggestion)}
                className="text-xs border-slate-600 bg-slate-800/50 text-slate-300 hover:bg-slate-700"
                disabled={isTyping}
              >
                <Sparkles className="w-3 h-3 mr-1" />
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
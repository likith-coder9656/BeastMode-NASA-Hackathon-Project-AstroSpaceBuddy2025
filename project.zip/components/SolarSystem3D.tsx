import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Play, Pause, RotateCcw, Info } from 'lucide-react';

interface PlanetData {
  name: string;
  radius: number;
  distance: number;
  color: string;
  rotationSpeed: number;
  orbitSpeed: number;
  description: string;
  facts: string[];
  temperature: string;
  moons: number;
  mass: string;
}

const planetsData: PlanetData[] = [
  {
    name: 'Mercury',
    radius: 8,
    distance: 80,
    color: '#8C7853',
    rotationSpeed: 4,
    orbitSpeed: 88,
    description: 'The smallest planet and closest to the Sun',
    facts: ['Shortest year: 88 Earth days', 'No atmosphere', 'Extreme temperature variations'],
    temperature: '-173°C to 427°C',
    moons: 0,
    mass: '3.30 × 10²³ kg'
  },
  {
    name: 'Venus',
    radius: 12,
    distance: 110,
    color: '#FFC649',
    rotationSpeed: 2,
    orbitSpeed: 225,
    description: 'The hottest planet with a toxic atmosphere',
    facts: ['Rotates backwards', 'Hottest planet', 'Thick CO2 atmosphere'],
    temperature: '462°C average',
    moons: 0,
    mass: '4.87 × 10²⁴ kg'
  },
  {
    name: 'Earth',
    radius: 14,
    distance: 140,
    color: '#6B93D6',
    rotationSpeed: 24,
    orbitSpeed: 365,
    description: 'Our home planet, the only known planet with life',
    facts: ['71% covered by water', 'Only known planet with life', 'One natural satellite'],
    temperature: '-89°C to 58°C',
    moons: 1,
    mass: '5.97 × 10²⁴ kg'
  },
  {
    name: 'Mars',
    radius: 10,
    distance: 170,
    color: '#CD5C5C',
    rotationSpeed: 25,
    orbitSpeed: 687,
    description: 'The Red Planet with the largest volcano in the solar system',
    facts: ['Has polar ice caps', 'Largest volcano: Olympus Mons', 'Evidence of past water'],
    temperature: '-87°C to -5°C',
    moons: 2,
    mass: '6.39 × 10²³ kg'
  },
  {
    name: 'Jupiter',
    radius: 30,
    distance: 220,
    color: '#D8CA9D',
    rotationSpeed: 10,
    orbitSpeed: 4333,
    description: 'The largest planet with a Great Red Spot storm',
    facts: ['Largest planet', 'Great Red Spot storm', 'Has a ring system'],
    temperature: '-108°C average',
    moons: 95,
    mass: '1.90 × 10²⁷ kg'
  },
  {
    name: 'Saturn',
    radius: 26,
    distance: 270,
    color: '#FAD5A5',
    rotationSpeed: 11,
    orbitSpeed: 10759,
    description: 'Famous for its beautiful ring system',
    facts: ['Prominent ring system', 'Less dense than water', 'Many shepherd moons'],
    temperature: '-139°C average',
    moons: 146,
    mass: '5.68 × 10²⁶ kg'
  }
];

export function SolarSystem3D() {
  const [isAnimating, setIsAnimating] = useState(true);
  const [selectedPlanet, setSelectedPlanet] = useState<PlanetData | null>(null);
  const [showPlanetInfo, setShowPlanetInfo] = useState(false);

  const handlePlanetClick = (planet: PlanetData) => {
    setSelectedPlanet(planet);
    setShowPlanetInfo(true);
  };

  const resetView = () => {
    setSelectedPlanet(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Interactive Solar System</h2>
          <p className="text-slate-400">Click on planets to learn more about them</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            onClick={() => setIsAnimating(!isAnimating)}
            variant="outline"
            className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700"
          >
            {isAnimating ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isAnimating ? 'Pause' : 'Play'}
          </Button>
          
          <Button
            onClick={resetView}
            variant="outline"
            className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset View
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Solar System Visualization */}
        <div className="lg:col-span-3">
          <Card className="bg-slate-800/50 border-slate-700 h-[600px] overflow-hidden">
            <CardContent className="p-8 h-full flex items-center justify-center relative">
              <div className="relative w-full h-full flex items-center justify-center">
                {/* Sun */}
                <div className="absolute w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full shadow-lg shadow-yellow-500/30 z-10 animate-pulse">
                  <div className="absolute inset-1 bg-gradient-to-br from-yellow-300 to-orange-400 rounded-full"></div>
                </div>

                {/* Planets and Orbits */}
                {planetsData.map((planet, index) => (
                  <div key={planet.name} className="absolute inset-0 flex items-center justify-center">
                    {/* Orbit */}
                    <div 
                      className="absolute border border-slate-600/30 rounded-full"
                      style={{
                        width: `${planet.distance * 2}px`,
                        height: `${planet.distance * 2}px`,
                      }}
                    />
                    
                    {/* Planet */}
                    <div
                      className={`absolute rounded-full cursor-pointer hover:scale-110 transition-all duration-300 ${
                        isAnimating ? 'animate-spin' : ''
                      }`}
                      style={{
                        width: `${planet.radius}px`,
                        height: `${planet.radius}px`,
                        backgroundColor: planet.color,
                        transformOrigin: `50% ${planet.distance}px`,
                        transform: `rotate(${index * 45}deg) translateY(-${planet.distance}px)`,
                        animationDuration: isAnimating ? `${planet.orbitSpeed / 50}s` : '0s',
                        animationDirection: 'reverse',
                        boxShadow: `0 0 ${planet.radius / 2}px ${planet.color}40`,
                      }}
                      onClick={() => handlePlanetClick(planet)}
                      title={planet.name}
                    >
                      {/* Planet surface details */}
                      <div className="absolute inset-0.5 rounded-full bg-gradient-to-br from-white/20 to-transparent"></div>
                      
                      {/* Saturn's rings */}
                      {planet.name === 'Saturn' && (
                        <>
                          <div 
                            className="absolute border-2 border-slate-300/60 rounded-full"
                            style={{
                              width: `${planet.radius * 1.8}px`,
                              height: `${planet.radius * 1.8}px`,
                              top: '50%',
                              left: '50%',
                              transform: 'translate(-50%, -50%)',
                            }}
                          />
                          <div 
                            className="absolute border border-slate-300/40 rounded-full"
                            style={{
                              width: `${planet.radius * 1.5}px`,
                              height: `${planet.radius * 1.5}px`,
                              top: '50%',
                              left: '50%',
                              transform: 'translate(-50%, -50%)',
                            }}
                          />
                        </>
                      )}
                    </div>
                  </div>
                ))}

                {/* Background stars */}
                <div className="absolute inset-0 pointer-events-none">
                  {Array.from({ length: 50 }).map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
                      style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                        animationDelay: `${Math.random() * 3}s`,
                        opacity: Math.random() * 0.8 + 0.2,
                      }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Planet Information Panel */}
        <div className="space-y-4">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-white">
                <Info className="w-5 h-5 text-blue-400" />
                <span>Controls</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="text-slate-300">
                <p className="font-medium text-white mb-1">Instructions:</p>
                <ul className="space-y-1">
                  <li>• Click planets to view details</li>
                  <li>• Use Play/Pause to control orbits</li>
                  <li>• Hover over planets for names</li>
                  <li>• Reset view to clear selection</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Planet Scale Guide</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="grid grid-cols-1 gap-2 text-xs">
                {planetsData.map((planet) => (
                  <div
                    key={planet.name}
                    className="flex items-center justify-between p-2 bg-slate-700/50 rounded cursor-pointer hover:bg-slate-700 transition-colors"
                    onClick={() => handlePlanetClick(planet)}
                  >
                    <div className="flex items-center space-x-2">
                      <div 
                        className="rounded-full" 
                        style={{ 
                          backgroundColor: planet.color,
                          width: `${Math.max(planet.radius / 2, 8)}px`,
                          height: `${Math.max(planet.radius / 2, 8)}px`
                        }}
                      />
                      <span className="text-white font-medium">{planet.name}</span>
                    </div>
                    <span className="text-slate-400">{planet.moons} moon{planet.moons !== 1 ? 's' : ''}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Planet Detail Dialog */}
      <Dialog open={showPlanetInfo} onOpenChange={setShowPlanetInfo}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-2xl">
          {selectedPlanet && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center space-x-3">
                  <div 
                    className="w-6 h-6 rounded-full" 
                    style={{ backgroundColor: selectedPlanet.color }}
                  />
                  <span>{selectedPlanet.name}</span>
                  <Badge variant="secondary" className="ml-auto">
                    {selectedPlanet.moons} moon{selectedPlanet.moons !== 1 ? 's' : ''}
                  </Badge>
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <p className="text-slate-300 leading-relaxed">
                  {selectedPlanet.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-slate-700/50 rounded-lg">
                    <div className="text-sm text-slate-400 mb-1">Temperature</div>
                    <div className="font-medium">{selectedPlanet.temperature}</div>
                  </div>
                  <div className="p-3 bg-slate-700/50 rounded-lg">
                    <div className="text-sm text-slate-400 mb-1">Mass</div>
                    <div className="font-medium">{selectedPlanet.mass}</div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Interesting Facts:</h4>
                  <ul className="space-y-1">
                    {selectedPlanet.facts.map((fact, index) => (
                      <li key={index} className="text-slate-300 text-sm">
                        • {fact}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
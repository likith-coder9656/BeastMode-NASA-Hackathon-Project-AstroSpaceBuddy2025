import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Brain, Trophy, RotateCcw, Sparkles, CheckCircle, XCircle } from 'lucide-react';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

interface QuizState {
  currentQuestion: number;
  score: number;
  answers: (number | null)[];
  showResults: boolean;
  selectedAnswer: number | null;
  showExplanation: boolean;
}

const spaceQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "Which planet is known as the 'Red Planet'?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correctAnswer: 1,
    explanation: "Mars is called the Red Planet because of its reddish appearance, which comes from iron oxide (rust) on its surface.",
    difficulty: "Easy"
  },
  {
    id: 2,
    question: "How long does it take for light from the Sun to reach Earth?",
    options: ["8 minutes", "1 hour", "1 day", "1 second"],
    correctAnswer: 0,
    explanation: "Light from the Sun takes approximately 8 minutes and 20 seconds to travel the 93 million miles to Earth.",
    difficulty: "Medium"
  },
  {
    id: 3,
    question: "What is the largest moon in our solar system?",
    options: ["Europa", "Titan", "Ganymede", "Io"],
    correctAnswer: 2,
    explanation: "Ganymede, one of Jupiter's moons, is the largest moon in our solar system and is even larger than Mercury.",
    difficulty: "Medium"
  },
  {
    id: 4,
    question: "Which spacecraft was the first to land humans on the Moon?",
    options: ["Apollo 10", "Apollo 11", "Apollo 12", "Gemini 7"],
    correctAnswer: 1,
    explanation: "Apollo 11 was the first mission to successfully land humans on the Moon in July 1969, with Neil Armstrong and Buzz Aldrin.",
    difficulty: "Easy"
  },
  {
    id: 5,
    question: "What type of star will our Sun eventually become?",
    options: ["Black hole", "Neutron star", "White dwarf", "Red giant"],
    correctAnswer: 2,
    explanation: "Our Sun will eventually expand into a red giant, then shed its outer layers and become a white dwarf star.",
    difficulty: "Hard"
  },
  {
    id: 6,
    question: "Which planet has the most extensive ring system?",
    options: ["Jupiter", "Saturn", "Uranus", "Neptune"],
    correctAnswer: 1,
    explanation: "Saturn has the most extensive and visible ring system, made up of countless ice and rock particles.",
    difficulty: "Easy"
  },
  {
    id: 7,
    question: "What is the closest star to our solar system?",
    options: ["Sirius", "Proxima Centauri", "Alpha Centauri A", "Vega"],
    correctAnswer: 1,
    explanation: "Proxima Centauri, part of the Alpha Centauri system, is the closest star to our solar system at 4.24 light-years away.",
    difficulty: "Medium"
  },
  {
    id: 8,
    question: "How many Earth days does it take for Venus to complete one rotation?",
    options: ["24 hours", "116 days", "243 days", "365 days"],
    correctAnswer: 2,
    explanation: "Venus has an extremely slow rotation, taking 243 Earth days to complete one rotation on its axis.",
    difficulty: "Hard"
  }
];

export function SpaceQuiz() {
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestion: 0,
    score: 0,
    answers: new Array(spaceQuestions.length).fill(null),
    showResults: false,
    selectedAnswer: null,
    showExplanation: false
  });

  const [questions, setQuestions] = useState<QuizQuestion[]>([]);

  useEffect(() => {
    generateNewQuiz();
  }, []);

  const generateNewQuiz = () => {
    // Shuffle questions for variety
    const shuffled = [...spaceQuestions].sort(() => Math.random() - 0.5);
    setQuestions(shuffled.slice(0, 5)); // Select 5 random questions
    
    setQuizState({
      currentQuestion: 0,
      score: 0,
      answers: new Array(5).fill(null),
      showResults: false,
      selectedAnswer: null,
      showExplanation: false
    });
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setQuizState(prev => ({
      ...prev,
      selectedAnswer: answerIndex
    }));
  };

  const handleSubmitAnswer = () => {
    if (quizState.selectedAnswer === null) return;

    const currentQ = questions[quizState.currentQuestion];
    const isCorrect = quizState.selectedAnswer === currentQ.correctAnswer;
    
    const newAnswers = [...quizState.answers];
    newAnswers[quizState.currentQuestion] = quizState.selectedAnswer;
    
    setQuizState(prev => ({
      ...prev,
      answers: newAnswers,
      score: isCorrect ? prev.score + 1 : prev.score,
      showExplanation: true
    }));
  };

  const handleNextQuestion = () => {
    if (quizState.currentQuestion < questions.length - 1) {
      setQuizState(prev => ({
        ...prev,
        currentQuestion: prev.currentQuestion + 1,
        selectedAnswer: null,
        showExplanation: false
      }));
    } else {
      setQuizState(prev => ({
        ...prev,
        showResults: true
      }));
    }
  };

  const getScoreMessage = () => {
    const percentage = (quizState.score / questions.length) * 100;
    if (percentage >= 80) return "🚀 Excellent! You're a space expert!";
    if (percentage >= 60) return "⭐ Great job! You know your space facts!";
    if (percentage >= 40) return "🌟 Good effort! Keep exploring the cosmos!";
    return "🌙 Keep learning! The universe has much to discover!";
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-600';
      case 'Medium': return 'bg-yellow-600';
      case 'Hard': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  if (questions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Brain className="w-12 h-12 text-purple-400 mx-auto mb-4 animate-pulse" />
          <p className="text-white">Generating space quiz...</p>
        </div>
      </div>
    );
  }

  if (quizState.showResults) {
    return (
      <div className="max-w-2xl mx-auto">
        <Card className="bg-slate-800/50 border-slate-700 text-center">
          <CardHeader>
            <CardTitle className="flex items-center justify-center space-x-2 text-white">
              <Trophy className="w-6 h-6 text-yellow-400" />
              <span>Quiz Complete!</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-6xl font-bold text-purple-400">
              {quizState.score}/{questions.length}
            </div>
            
            <div className="text-xl text-white">
              {getScoreMessage()}
            </div>
            
            <div className="space-y-4">
              <Progress 
                value={(quizState.score / questions.length) * 100} 
                className="h-3"
              />
              <p className="text-slate-300">
                You scored {Math.round((quizState.score / questions.length) * 100)}% 
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-3">
              {questions.map((question, index) => (
                <div key={question.id} className="p-3 bg-slate-700/50 rounded-lg text-left">
                  <div className="flex items-start justify-between mb-2">
                    <p className="text-sm text-white font-medium">{question.question}</p>
                    {quizState.answers[index] === question.correctAnswer ? (
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 ml-2" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 ml-2" />
                    )}
                  </div>
                  <p className="text-xs text-slate-300">
                    Correct: {question.options[question.correctAnswer]}
                  </p>
                  {quizState.answers[index] !== question.correctAnswer && (
                    <p className="text-xs text-red-300">
                      Your answer: {question.options[quizState.answers[index]!]}
                    </p>
                  )}
                </div>
              ))}
            </div>
            
            <Button 
              onClick={generateNewQuiz}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Take New Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQuestion = questions[quizState.currentQuestion];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Space Knowledge Quiz</h2>
          <p className="text-slate-400">Test your knowledge of the cosmos</p>
        </div>
        <Button 
          onClick={generateNewQuiz}
          variant="outline"
          className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          New Quiz
        </Button>
      </div>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2 text-white">
              <Brain className="w-5 h-5 text-purple-400" />
              <span>Question {quizState.currentQuestion + 1} of {questions.length}</span>
            </CardTitle>
            <Badge className={getDifficultyColor(currentQuestion.difficulty)}>
              {currentQuestion.difficulty}
            </Badge>
          </div>
          <Progress 
            value={((quizState.currentQuestion + 1) / questions.length) * 100} 
            className="mt-2"
          />
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="text-lg text-white leading-relaxed">
            {currentQuestion.question}
          </div>

          <div className="grid gap-3">
            {currentQuestion.options.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className={`p-4 h-auto text-left justify-start border-slate-600 bg-slate-700/30 hover:bg-slate-700 text-white transition-all ${
                  quizState.selectedAnswer === index 
                    ? 'border-purple-500 bg-purple-500/20' 
                    : ''
                } ${
                  quizState.showExplanation && index === currentQuestion.correctAnswer
                    ? 'border-green-500 bg-green-500/20'
                    : ''
                } ${
                  quizState.showExplanation && 
                  quizState.selectedAnswer === index && 
                  index !== currentQuestion.correctAnswer
                    ? 'border-red-500 bg-red-500/20'
                    : ''
                }`}
                onClick={() => !quizState.showExplanation && handleAnswerSelect(index)}
                disabled={quizState.showExplanation}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full border-2 border-current flex items-center justify-center text-sm">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <span>{option}</span>
                  {quizState.showExplanation && index === currentQuestion.correctAnswer && (
                    <CheckCircle className="w-5 h-5 text-green-400 ml-auto" />
                  )}
                  {quizState.showExplanation && 
                   quizState.selectedAnswer === index && 
                   index !== currentQuestion.correctAnswer && (
                    <XCircle className="w-5 h-5 text-red-400 ml-auto" />
                  )}
                </div>
              </Button>
            ))}
          </div>

          {quizState.showExplanation && (
            <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
              <div className="flex items-start space-x-2">
                <Brain className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-white mb-1">Explanation:</p>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {currentQuestion.explanation}
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between">
            <div className="text-sm text-slate-400">
              Score: {quizState.score}/{quizState.currentQuestion + (quizState.showExplanation ? 1 : 0)}
            </div>
            
            <div className="space-x-2">
              {!quizState.showExplanation ? (
                <Button
                  onClick={handleSubmitAnswer}
                  disabled={quizState.selectedAnswer === null}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  Submit Answer
                </Button>
              ) : (
                <Button
                  onClick={handleNextQuestion}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {quizState.currentQuestion < questions.length - 1 ? 'Next Question' : 'View Results'}
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
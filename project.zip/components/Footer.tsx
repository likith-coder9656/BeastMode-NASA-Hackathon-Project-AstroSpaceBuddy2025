import React from 'react';
import { Card } from './ui/card';
import { Rocket, Github, Twitter, Mail, Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-700/50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-white">AstroBuddy</h3>
                <p className="text-xs text-slate-400">Your AI Space Companion</p>
              </div>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              Exploring the cosmos through real-time NASA data, interactive 3D visualizations, 
              and AI-powered learning experiences.
            </p>
          </div>

          {/* Features */}
          <div>
            <h4 className="font-semibold text-white mb-4">Features</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">AI Chatbot</a></li>
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">Live NASA Data</a></li>
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">3D Solar System</a></li>
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">Space Quizzes</a></li>
            </ul>
          </div>

          {/* Data Sources */}
          <div>
            <h4 className="font-semibold text-white mb-4">Data Sources</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">NASA APOD API</a></li>
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">Mars Weather API</a></li>
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">ISS Location API</a></li>
              <li><a href="#" className="text-slate-300 hover:text-purple-400 transition-colors">NeoWs API</a></li>
            </ul>
          </div>

          {/* Team & Contact */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <div className="px-3 py-1 bg-gradient-to-r from-orange-500 to-red-500 rounded-full">
                <h4 className="font-bold text-white text-sm">🏆 TEAM BEASTMODE</h4>
              </div>
            </div>
            <div className="space-y-3">
              <div className="text-sm text-slate-300">
                <p className="font-medium text-white mb-1">Lead Developer: Likith</p>
                <p>Built for the hackathon with passion for space exploration and education.</p>
              </div>
              <div className="flex space-x-3">
                <a href="#" className="text-slate-400 hover:text-purple-400 transition-colors">
                  <Github className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-400 hover:text-purple-400 transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="text-slate-400 hover:text-purple-400 transition-colors">
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-700/50">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="text-sm text-slate-400">
              © 2025 AstroBuddy by <span className="text-orange-400 font-semibold">Team BeastMode</span> • 
              Developed by <span className="text-white font-medium">Likith</span> • 
              Made with <Heart className="w-4 h-4 inline text-red-400" /> for space exploration.
            </div>
            
            <div className="flex items-center space-x-6 text-sm">
              <a href="#" className="text-slate-400 hover:text-purple-400 transition-colors">Privacy Policy</a>
              <a href="#" className="text-slate-400 hover:text-purple-400 transition-colors">Terms of Service</a>
              <a href="#" className="text-slate-400 hover:text-purple-400 transition-colors">API Documentation</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
import React, { useEffect, useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Rocket, Sparkles, Globe, Brain, MessageCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroProps {
  setActiveTab: (tab: string) => void;
}

export function Hero({ setActiveTab }: HeroProps) {
  const [animatedText, setAnimatedText] = useState('');
  const fullText = 'Welcome to AstroBuddy - Your Personal AI Space Companion';

  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setAnimatedText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 50);

    return () => clearInterval(timer);
  }, []);

  const features = [
    {
      icon: <MessageCircle className="w-8 h-8 text-purple-400" />,
      title: "AI Chatbot",
      description: "Chat with AstroBuddy for real-time space information and NASA data insights."
    },
    {
      icon: <Rocket className="w-8 h-8 text-blue-400" />,
      title: "Live Space Data",
      description: "Get real-time updates on Mars weather, ISS location, and daily astronomy pictures."
    },
    {
      icon: <Globe className="w-8 h-8 text-green-400" />,
      title: "3D Solar System",
      description: "Explore an interactive 3D model of our solar system with detailed planet information."
    },
    {
      icon: <Brain className="w-8 h-8 text-orange-400" />,
      title: "Space Quizzes",
      description: "Test your space knowledge with AI-generated quizzes and learn fascinating facts."
    }
  ];

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-900/50 to-blue-900/50 backdrop-blur-sm border border-slate-700/50">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1656087279606-c33e8980cf30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMG5lYnVsYSUyMHN0YXJzfGVufDF8fHx8MTc1OTYyNjM1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Space nebula background"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/70 to-blue-900/70"></div>
        </div>
        
        <div className="relative z-10 px-8 py-16 text-center">
          <div className="mb-8">
            {/* Team Badge */}
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-500 to-red-500 px-4 py-2 rounded-full mb-4">
              <span className="text-white font-bold text-sm">🏆 TEAM BEASTMODE</span>
            </div>
            
            <div className="inline-flex p-4 bg-gradient-to-br from-purple-500 to-blue-600 rounded-2xl mb-6">
              <Rocket className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 min-h-[2em]">
              {animatedText}
              <span className="animate-pulse">|</span>
            </h1>
            
            {/* Developer Credit */}
            <div className="mb-4">
              <p className="text-lg text-purple-300 font-medium">
                Developed by <span className="text-white font-bold">Likith</span>
              </p>
              <p className="text-sm text-slate-400">Team BeastMode • Hackathon 2025</p>
            </div>
            
            <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
              Explore the cosmos with real-time NASA data, interactive 3D visualizations, 
              and an AI companion that makes space accessible and engaging for everyone.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => setActiveTab('explorer')}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Start Exploring
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => setActiveTab('chat')}
              className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Chat with AI
            </Button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => (
          <Card key={index} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-all duration-300 hover:scale-105">
            <CardContent className="p-6 text-center">
              <div className="mb-4 flex justify-center">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                {feature.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Team Achievement Banner */}
      <div className="bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-2xl p-6 text-center mb-8">
        <h3 className="text-2xl font-bold text-white mb-2">🏆 Team BeastMode Hackathon Project</h3>
        <p className="text-orange-200 mb-4">
          Showcasing cutting-edge space technology and AI innovation
        </p>
        <div className="flex flex-wrap justify-center gap-4 text-sm">
          <div className="px-4 py-2 bg-orange-500/20 rounded-full border border-orange-500/30">
            <span className="text-orange-300">💻 Developer: Likith</span>
          </div>
          <div className="px-4 py-2 bg-orange-500/20 rounded-full border border-orange-500/30">
            <span className="text-orange-300">🚀 Real NASA APIs</span>
          </div>
          <div className="px-4 py-2 bg-orange-500/20 rounded-full border border-orange-500/30">
            <span className="text-orange-300">🤖 AI-Powered</span>
          </div>
          <div className="px-4 py-2 bg-orange-500/20 rounded-full border border-orange-500/30">
            <span className="text-orange-300">🌌 3D Interactive</span>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
        <div className="p-6 rounded-xl bg-slate-800/30 border border-slate-700/50">
          <div className="text-3xl font-bold text-purple-400 mb-2">10,000+</div>
          <div className="text-slate-300">Space Facts</div>
        </div>
        <div className="p-6 rounded-xl bg-slate-800/30 border border-slate-700/50">
          <div className="text-3xl font-bold text-blue-400 mb-2">Real-Time</div>
          <div className="text-slate-300">NASA Data</div>
        </div>
        <div className="p-6 rounded-xl bg-slate-800/30 border border-slate-700/50">
          <div className="text-3xl font-bold text-green-400 mb-2">3D</div>
          <div className="text-slate-300">Interactive Models</div>
        </div>
        <div className="p-6 rounded-xl bg-slate-800/30 border border-slate-700/50">
          <div className="text-3xl font-bold text-orange-400 mb-2">AI-Powered</div>
          <div className="text-slate-300">Learning</div>
        </div>
      </div>
    </div>
  );
}
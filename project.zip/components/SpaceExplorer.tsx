import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  ChevronLeft, 
  ChevronRight, 
  Rocket, 
  Satellite, 
  Globe, 
  Star, 
  Telescope, 
  Calendar,
  BookOpen,
  HelpCircle,
  CheckCircle,
  Lightbulb,
  TrendingUp,
  Zap
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Slide {
  id: string;
  category: 'news' | 'blog' | 'update' | 'problem';
  title: string;
  subtitle?: string;
  content: string;
  imageUrl: string;
  tags: string[];
  date: string;
  readTime?: string;
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced';
  answer?: string;
}

const spaceSlides: Slide[] = [
  // News & Updates
  {
    id: '1',
    category: 'news',
    title: 'James Webb Space Telescope Discovers Most Distant Galaxy',
    subtitle: 'JADES-GS-z13-0 pushes cosmic frontiers',
    content: 'The James Webb Space Telescope has identified the most distant galaxy ever observed, dating back to just 325 million years after the Big Bang. This ancient galaxy, designated JADES-GS-z13-0, provides unprecedented insights into the early universe\'s formation and evolution. The discovery demonstrates how massive galaxies formed much earlier than previously thought, challenging our understanding of cosmic evolution and star formation in the primordial universe.',
    imageUrl: 'https://images.unsplash.com/photo-1614732414444-096e5f1122d5?w=800',
    tags: ['JWST', 'Galaxy', 'Discovery', 'Deep Space'],
    date: '2025-01-15',
    readTime: '5 min read'
  },
  {
    id: '2',
    category: 'update',
    title: 'Mars Perseverance Rover Collects Historic Rock Samples',
    subtitle: 'Potential biosignatures detected in Martian geology',
    content: 'NASA\'s Perseverance rover has successfully collected and cached 24 rock samples from Mars\' Jezero Crater, with several showing potential signs of ancient microbial life. These samples contain organic compounds and mineral formations that could indicate past biological activity. The Mars Sample Return mission, planned for the late 2020s, will bring these precious specimens back to Earth for detailed laboratory analysis, potentially answering the fundamental question of whether life ever existed on Mars.',
    imageUrl: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=800',
    tags: ['Mars', 'Perseverance', 'Samples', 'Astrobiology'],
    date: '2025-01-12',
    readTime: '4 min read'
  },
  {
    id: '3',
    category: 'blog',
    title: 'The International Space Station: A Decade of Scientific Breakthroughs',
    subtitle: 'Celebrating continuous human presence in space',
    content: 'For over two decades, the International Space Station has served as humanity\'s outpost in space, conducting over 3,000 scientific experiments across multiple disciplines. From developing new medical treatments in microgravity to studying climate change from orbit, the ISS has revolutionized our understanding of science, technology, and human adaptation to space. Recent experiments include protein crystal growth for drug development, advanced materials research, and studies on how long-duration spaceflight affects human physiology.',
    imageUrl: 'https://images.unsplash.com/photo-1589908049670-266634a09bb8?w=800',
    tags: ['ISS', 'Research', 'Microgravity', 'Space Medicine'],
    date: '2025-01-10',
    readTime: '6 min read'
  },
  {
    id: '4',
    category: 'news',
    title: 'Breakthrough in Asteroid Mining Technology',
    subtitle: 'Near-Earth asteroid 2023 BU contains rare earth elements',
    content: 'Scientists have confirmed that near-Earth asteroid 2023 BU contains significant deposits of rare earth elements, including platinum, iridium, and other precious metals essential for modern technology. Advanced spectroscopic analysis reveals concentrations 10 times higher than Earth\'s richest mines. This discovery has sparked renewed interest in asteroid mining missions, with several private companies announcing plans for robotic mining operations within the next decade, potentially revolutionizing resource acquisition and space-based manufacturing.',
    imageUrl: 'https://images.unsplash.com/photo-1628126235206-5260b9ea6441?w=800',
    tags: ['Asteroid', 'Mining', 'Resources', 'Technology'],
    date: '2025-01-08',
    readTime: '4 min read'
  },
  {
    id: '5',
    category: 'update',
    title: 'Solar Storm Activity Reaches 11-Year Peak',
    subtitle: 'Solar Cycle 25 shows unprecedented coronal mass ejections',
    content: 'The Sun has entered the most active phase of its 11-year solar cycle, with Solar Cycle 25 producing the strongest coronal mass ejections recorded in over a decade. These solar storms have created spectacular auroras visible as far south as Mexico and caused temporary disruptions to satellite communications and GPS systems. Space weather experts are monitoring increased solar activity that could impact astronauts on the ISS and future lunar missions, leading to enhanced space weather prediction systems.',
    imageUrl: 'https://images.unsplash.com/photo-1614732484003-ef9881555dc3?w=800',
    tags: ['Solar Storm', 'Space Weather', 'Aurora', 'Satellites'],
    date: '2025-01-05',
    readTime: '5 min read'
  },
  {
    id: '6',
    category: 'blog',
    title: 'Exoplanet Atmospheres: Windows to Alien Worlds',
    subtitle: 'JWST reveals atmospheric compositions beyond our solar system',
    content: 'The James Webb Space Telescope is revolutionizing exoplanet science by analyzing atmospheric compositions of distant worlds with unprecedented detail. Recent observations of WASP-96b revealed water vapor, hazes, and clouds in its atmosphere, while studies of the TRAPPIST-1 system suggest several planets may have retained their atmospheres despite intense stellar radiation. These atmospheric signatures help scientists determine planetary habitability, climate patterns, and potential biosignatures that could indicate the presence of life.',
    imageUrl: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=800',
    tags: ['Exoplanets', 'Atmospheres', 'JWST', 'Habitability'],
    date: '2025-01-03',
    readTime: '7 min read'
  },

  // Problem Statements with Solutions
  {
    id: '7',
    category: 'problem',
    title: 'The Fermi Paradox: Where is Everybody?',
    subtitle: 'Understanding the cosmic silence',
    content: 'Given the vast number of stars and potentially habitable planets in our galaxy, why haven\'t we encountered evidence of extraterrestrial intelligence? This fundamental question, known as the Fermi Paradox, challenges our assumptions about life in the universe.',
    answer: 'Several scientific explanations address the Fermi Paradox: **The Great Filter hypothesis** suggests that there\'s an evolutionary bottleneck that prevents most life from reaching advanced civilization status. This filter could be the emergence of life itself, the development of complex cells, or the transition to intelligence. **The Rare Earth hypothesis** proposes that while simple life may be common, complex life requires an extremely rare combination of factors including a stable star, proper planetary size, magnetic field protection, and a large moon for tidal stability. **Technological self-destruction** suggests that advanced civilizations may inevitably destroy themselves through nuclear war, climate change, or other catastrophic technologies before achieving interstellar communication. **The Zoo hypothesis** theorizes that advanced civilizations are aware of us but deliberately avoid contact to allow natural development, similar to wildlife preservation. **Distance and time scales** play a crucial role - our galaxy is so vast that even if civilizations exist, the probability of contact within human timescales is extremely low. Additionally, civilizations may rise and fall on different timescales, missing opportunities for communication across cosmic time.',
    imageUrl: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=800',
    tags: ['SETI', 'Astrobiology', 'Paradox', 'Intelligence'],
    date: '2025-01-01',
    difficulty: 'Advanced'
  },
  {
    id: '8',
    category: 'problem',
    title: 'How Do We Protect Astronauts from Cosmic Radiation?',
    subtitle: 'Solving long-duration spaceflight health challenges',
    content: 'During long-duration missions to Mars or beyond, astronauts face dangerous levels of cosmic radiation that could cause cancer, neurological damage, and other serious health problems. What are the most promising solutions to protect human health in deep space?',
    answer: 'Protecting astronauts from cosmic radiation requires a multi-layered approach combining **passive and active shielding technologies**. **Passive shielding** uses materials like polyethylene, aluminum, or water to absorb radiation, but adding enough mass for complete protection would make spacecraft impractically heavy. **Magnetic shielding** systems create artificial magnetic fields around spacecraft, deflecting charged particles similar to Earth\'s magnetosphere, though this requires significant power and complex engineering. **Pharmaceutical radioprotectors** include drugs that can reduce cellular damage from radiation exposure, such as antioxidants and DNA repair enhancers taken before and during exposure. **Biological approaches** involve selecting crew members with natural resistance to radiation damage and developing genetic therapies to enhance DNA repair mechanisms. **Mission planning strategies** time launches to avoid solar particle events, use planetary bodies for shielding during surface operations, and design spacecraft with dedicated radiation shelters for emergency protection. **Hybrid water shielding** systems serve dual purposes, using recycled water and waste as both life support resources and radiation protection. The most effective solution will likely combine lightweight electromagnetic deflection systems with strategic mission timing and pharmaceutical countermeasures.',
    imageUrl: 'https://images.unsplash.com/photo-1614728823936-d4b2d6c47ca0?w=800',
    tags: ['Radiation', 'Astronaut Safety', 'Deep Space', 'Shielding'],
    date: '2023-12-28',
    difficulty: 'Intermediate'
  },
  {
    id: '9',
    category: 'problem',
    title: 'Why Don\'t Planets Fall into the Sun?',
    subtitle: 'Understanding orbital mechanics and gravitational balance',
    content: 'If gravity pulls everything toward the Sun, why don\'t the planets simply fall into it? This fundamental question about orbital mechanics confuses many people learning about space science.',
    answer: 'Planets don\'t fall into the Sun because they are in **continuous free fall while moving sideways fast enough** to keep missing it. This concept involves several key principles: **Orbital velocity** - each planet moves at precisely the right speed to balance the Sun\'s gravitational pull. If a planet moved slower, it would spiral inward; if faster, it would escape to space. **Centripetal force** - gravity provides the inward force needed to keep planets moving in curved paths rather than straight lines. The gravitational attraction exactly equals the centrifugal force trying to pull the planet outward. **Conservation of angular momentum** - as the solar system formed from a rotating disk of gas and dust, the material retained its spin, which prevents everything from falling straight into the center. **Newton\'s first law** states that objects in motion tend to stay in motion unless acted upon by a force. Planets want to travel in straight lines, but gravity constantly curves their paths into elliptical orbits. **The analogy of a ball on a string** helps visualize this: when you swing a ball on a string, it doesn\'t fall toward your hand because its sideways motion balances the inward pull of the string. Similarly, planets\' orbital motion balances the Sun\'s gravitational pull, creating stable, long-lasting orbits that have persisted for billions of years.',
    imageUrl: 'https://images.unsplash.com/photo-1614313998906-b5cd9b1793c1?w=800',
    tags: ['Orbital Mechanics', 'Gravity', 'Physics', 'Solar System'],
    date: '2023-12-25',
    difficulty: 'Beginner'
  },
  {
    id: '10',
    category: 'problem',
    title: 'How Could We Terraform Mars?',
    subtitle: 'Engineering a habitable atmosphere on the Red Planet',
    content: 'Mars has a thin atmosphere, extreme cold, and deadly radiation. What would it take to transform Mars into a world where humans could live and breathe without life support systems?',
    answer: 'Terraforming Mars would require **massive atmospheric engineering over centuries or millennia**. The process involves several interconnected challenges: **Atmospheric thickening** - Mars\' atmosphere is 100 times thinner than Earth\'s, requiring addition of greenhouse gases like CO₂, methane, or synthetic compounds to create atmospheric pressure and retain heat. **Temperature regulation** - Mars averages -80°F, so we\'d need to warm the planet through greenhouse effects, orbital mirrors to reflect sunlight, or even redirecting comets to add water and heat. **Oxygen production** - Initially through industrial processes like splitting CO₂, then eventually through photosynthesis from engineered plants and algae adapted to Martian conditions. **Magnetic field protection** - Mars lacks a global magnetic field, allowing solar wind to strip away atmosphere. Solutions include artificial magnetic field generators at Lagrange points or planetary-scale electromagnetic systems. **Water cycle establishment** - Melting polar ice caps and subsurface water to create oceans, rivers, and weather patterns necessary for a stable climate system. **Soil remediation** - Martian soil contains toxic perchlorates that must be neutralized and enriched with organic matter to support plant life. **Biological introduction** - Carefully introduce extremophile bacteria, then plants, and eventually complex ecosystems while preventing contamination of potential native Martian life. **Timeline considerations** - Even with advanced technology, true terraforming would take 500-1000 years, making **paraterraforming** (enclosed habitable areas) a more practical near-term solution.',
    imageUrl: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=800',
    tags: ['Terraforming', 'Mars', 'Atmospheric Engineering', 'Colonization'],
    date: '2023-12-22',
    difficulty: 'Advanced'
  }
];

export function SpaceExplorer() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAnswer, setShowAnswer] = useState<string | null>(null);

  const filteredSlides = selectedCategory === 'all' 
    ? spaceSlides 
    : spaceSlides.filter(slide => slide.category === selectedCategory);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % filteredSlides.length);
    setShowAnswer(null);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + filteredSlides.length) % filteredSlides.length);
    setShowAnswer(null);
  };

  const getCurrentSlide = () => filteredSlides[currentSlide];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'news': return <TrendingUp className="w-4 h-4" />;
      case 'blog': return <BookOpen className="w-4 h-4" />;
      case 'update': return <Zap className="w-4 h-4" />;
      case 'problem': return <HelpCircle className="w-4 h-4" />;
      default: return <Star className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'news': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'blog': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'update': return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 'problem': return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
      default: return 'bg-slate-500/20 text-slate-300 border-slate-500/30';
    }
  };

  if (filteredSlides.length === 0) return null;

  const slide = getCurrentSlide();

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-500 to-red-500 px-4 py-2 rounded-full mb-4">
          <Telescope className="w-4 h-4 text-white" />
          <span className="text-white font-bold text-sm">TEAM BEASTMODE SPACE EXPLORER</span>
        </div>
        <h1 className="text-4xl font-bold text-white mb-2">Space Knowledge Hub</h1>
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Discover the latest space news, in-depth articles, and solve fascinating cosmic problems with professional insights from Team BeastMode
        </p>
      </div>

      {/* Category Filters */}
      <div className="flex flex-wrap justify-center gap-4">
        <Button
          onClick={() => {
            setSelectedCategory('all');
            setCurrentSlide(0);
            setShowAnswer(null);
          }}
          variant={selectedCategory === 'all' ? 'default' : 'outline'}
          className={selectedCategory === 'all' 
            ? 'bg-purple-600 hover:bg-purple-700' 
            : 'border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700'
          }
        >
          <Star className="w-4 h-4 mr-2" />
          All Content
        </Button>
        {['news', 'blog', 'update', 'problem'].map((category) => (
          <Button
            key={category}
            onClick={() => {
              setSelectedCategory(category);
              setCurrentSlide(0);
              setShowAnswer(null);
            }}
            variant={selectedCategory === category ? 'default' : 'outline'}
            className={selectedCategory === category 
              ? 'bg-purple-600 hover:bg-purple-700' 
              : 'border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700'
            }
          >
            {getCategoryIcon(category)}
            <span className="ml-2 capitalize">{category === 'problem' ? 'Q&A' : category}</span>
          </Button>
        ))}
      </div>

      {/* Main Slide */}
      <Card className="bg-slate-800/50 border-slate-700 overflow-hidden">
        <div className="relative h-64 md:h-80">
          <ImageWithFallback
            src={slide.imageUrl}
            alt={slide.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />
          
          {/* Navigation Arrows */}
          <Button
            onClick={prevSlide}
            variant="ghost"
            size="icon"
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-slate-800/80 hover:bg-slate-700/80 text-white"
          >
            <ChevronLeft className="w-6 h-6" />
          </Button>
          <Button
            onClick={nextSlide}
            variant="ghost"
            size="icon"
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-slate-800/80 hover:bg-slate-700/80 text-white"
          >
            <ChevronRight className="w-6 h-6" />
          </Button>

          {/* Slide Counter */}
          <div className="absolute top-4 right-4 bg-slate-800/80 backdrop-blur-sm px-3 py-1 rounded-full">
            <span className="text-white text-sm font-medium">
              {currentSlide + 1} / {filteredSlides.length}
            </span>
          </div>
        </div>

        <CardContent className="p-8">
          <div className="space-y-6">
            {/* Category and Metadata */}
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <Badge className={`border ${getCategoryColor(slide.category)}`}>
                  {getCategoryIcon(slide.category)}
                  <span className="ml-1 capitalize">
                    {slide.category === 'problem' ? 'Q&A' : slide.category}
                  </span>
                </Badge>
                {slide.difficulty && (
                  <Badge variant="outline" className="border-slate-600 text-slate-300">
                    <Lightbulb className="w-3 h-3 mr-1" />
                    {slide.difficulty}
                  </Badge>
                )}
              </div>
              <div className="flex items-center space-x-4 text-sm text-slate-400">
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(slide.date).toLocaleDateString()}</span>
                </div>
                {slide.readTime && (
                  <span>{slide.readTime}</span>
                )}
              </div>
            </div>

            {/* Title and Subtitle */}
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">{slide.title}</h2>
              {slide.subtitle && (
                <p className="text-xl text-purple-300 font-medium">{slide.subtitle}</p>
              )}
            </div>

            {/* Content */}
            <div className="prose prose-lg prose-invert max-w-none">
              <p className="text-slate-300 leading-relaxed">{slide.content}</p>
            </div>

            {/* Answer Section for Problems */}
            {slide.category === 'problem' && slide.answer && (
              <div className="border-t border-slate-700 pt-6">
                <Button
                  onClick={() => setShowAnswer(showAnswer === slide.id ? null : slide.id)}
                  className="mb-4 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                >
                  {showAnswer === slide.id ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Hide Solution
                    </>
                  ) : (
                    <>
                      <HelpCircle className="w-4 h-4 mr-2" />
                      Show Professional Solution
                    </>
                  )}
                </Button>
                
                {showAnswer === slide.id && (
                  <div className="bg-slate-900/50 border border-slate-600 rounded-lg p-6">
                    <h4 className="text-lg font-semibold text-green-400 mb-3 flex items-center">
                      <CheckCircle className="w-5 h-5 mr-2" />
                      Professional Solution
                    </h4>
                    <div className="prose prose-lg prose-invert max-w-none">
                      <div 
                        className="text-slate-300 leading-relaxed"
                        dangerouslySetInnerHTML={{ 
                          __html: slide.answer.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>') 
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tags */}
            <div className="flex flex-wrap gap-2">
              {slide.tags.map((tag, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="border-slate-600 text-slate-400 bg-slate-800/30"
                >
                  #{tag}
                </Badge>
              ))}
            </div>

            {/* Team Credit */}
            <div className="border-t border-slate-700 pt-4">
              <div className="flex items-center justify-between">
                <div className="text-sm text-slate-400">
                  Curated by <span className="text-orange-400 font-semibold">Team BeastMode</span> • 
                  Developed by <span className="text-white font-medium">Likith</span>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={prevSlide}
                    variant="outline"
                    size="sm"
                    className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700"
                  >
                    Previous
                  </Button>
                  <Button
                    onClick={nextSlide}
                    size="sm"
                    className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Navigation */}
      <div className="flex justify-center space-x-2">
        {filteredSlides.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setCurrentSlide(index);
              setShowAnswer(null);
            }}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentSlide 
                ? 'bg-purple-500 scale-125' 
                : 'bg-slate-600 hover:bg-slate-500'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
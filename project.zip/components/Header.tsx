import React from 'react';
import { Button } from './ui/button';
import { Moon, Sun, Rocket } from 'lucide-react';

interface HeaderProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export function Header({ isDarkMode, toggleTheme }: HeaderProps) {
  return (
    <header className="border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg">
            <Rocket className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">AstroBuddy</h1>
            <p className="text-sm text-slate-300">Your AI Space Companion</p>
          </div>
          <div className="hidden md:block ml-4 pl-4 border-l border-slate-600">
            <div className="text-xs text-orange-400 font-bold">TEAM BEASTMODE</div>
            <div className="text-xs text-slate-400">by Likith</div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={toggleTheme}
            className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
        </div>
      </div>
    </header>
  );
}
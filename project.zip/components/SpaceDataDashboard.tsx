import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { RefreshCw, MapPin, Thermometer, Wind, Image, Calendar, Satellite, Zap } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface APODData {
  title: string;
  url: string;
  explanation: string;
  date: string;
  media_type: string;
}

interface MarsWeatherData {
  sol: number;
  temperature: {
    high: number;
    low: number;
  };
  pressure: number;
  wind_speed: number;
  season: string;
}

interface ISSLocationData {
  latitude: number;
  longitude: number;
  altitude: number;
  velocity: number;
  visibility: string;
}

interface AsteroidData {
  id: string;
  name: string;
  diameter: number;
  distance: number;
  velocity: number;
  hazardous: boolean;
  approach_date: string;
}

export function SpaceDataDashboard() {
  const [apodData, setApodData] = useState<APODData | null>(null);
  const [marsWeather, setMarsWeather] = useState<MarsWeatherData | null>(null);
  const [issLocation, setIssLocation] = useState<ISSLocationData | null>(null);
  const [asteroids, setAsteroids] = useState<AsteroidData[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  // Load real NASA data from our backend
  useEffect(() => {
    loadRealData();
  }, []);

  const loadRealData = async () => {
    try {
      const { projectId, publicAnonKey } = await import('../utils/supabase/info');
      const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-8f12e3f9`;
      
      // Fetch APOD data
      try {
        const apodResponse = await fetch(`${baseUrl}/nasa/apod`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        });
        const apodResult = await apodResponse.json();
        if (apodResult.success) {
          setApodData({
            title: apodResult.data.title,
            url: apodResult.data.url,
            explanation: apodResult.data.explanation,
            date: apodResult.data.date,
            media_type: apodResult.data.media_type || 'image'
          });
        }
      } catch (error) {
        console.error('Failed to fetch APOD data:', error);
      }

      // Fetch Mars weather data
      try {
        const marsResponse = await fetch(`${baseUrl}/mars/weather`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        });
        const marsResult = await marsResponse.json();
        if (marsResult.success) {
          setMarsWeather(marsResult.data);
        }
      } catch (error) {
        console.error('Failed to fetch Mars weather data:', error);
      }

      // Fetch ISS location data
      try {
        const issResponse = await fetch(`${baseUrl}/iss/location`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        });
        const issResult = await issResponse.json();
        if (issResult.success) {
          setIssLocation({
            latitude: issResult.data.latitude,
            longitude: issResult.data.longitude,
            altitude: 408, // Default ISS altitude
            velocity: 27600, // Default ISS velocity
            visibility: "Live"
          });
        }
      } catch (error) {
        console.error('Failed to fetch ISS location data:', error);
      }

      // Fetch Near Earth Objects data
      try {
        const neoResponse = await fetch(`${baseUrl}/nasa/neo`, {
          headers: { 'Authorization': `Bearer ${publicAnonKey}` }
        });
        const neoResult = await neoResponse.json();
        if (neoResult.success) {
          const asteroidData: AsteroidData[] = [];
          
          Object.values(neoResult.data.near_earth_objects).forEach((dayAsteroids: any) => {
            dayAsteroids.forEach((asteroid: any) => {
              if (asteroidData.length < 5) { // Limit to 5 asteroids
                asteroidData.push({
                  id: asteroid.id,
                  name: asteroid.name,
                  diameter: Math.round(asteroid.estimated_diameter.meters.estimated_diameter_avg),
                  distance: parseFloat(asteroid.close_approach_data[0].miss_distance.lunar),
                  velocity: parseFloat(asteroid.close_approach_data[0].relative_velocity.kilometers_per_second),
                  hazardous: asteroid.is_potentially_hazardous_asteroid,
                  approach_date: asteroid.close_approach_data[0].close_approach_date
                });
              }
            });
          });
          
          setAsteroids(asteroidData);
        }
      } catch (error) {
        console.error('Failed to fetch NEO data:', error);
      }

      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to load space data:', error);
      // Fallback to mock data if API fails
      loadMockData();
    }
  };

  const loadMockData = () => {
    // Fallback mock data
    setApodData({
      title: "The Great Nebula in Orion",
      url: "https://images.unsplash.com/photo-1656087279606-c33e8980cf30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMG5lYnVsYSUyMHN0YXJzfGVufDF8fHx8MTc1OTYyNjM1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      explanation: "The Great Nebula in Orion, also known as M42, is one of the most photographed, studied, and admired celestial features. This image reveals the remarkable detail of this dynamic star-forming region located about 1,500 light-years away.",
      date: new Date().toISOString().split('T')[0],
      media_type: "image"
    });

    setMarsWeather({
      sol: 3876,
      temperature: { high: -23, low: -89 },
      pressure: 748,
      wind_speed: 5.2,
      season: "Northern Winter"
    });

    setIssLocation({
      latitude: 45.7311,
      longitude: -122.9447,
      altitude: 408,
      velocity: 27600,
      visibility: "Demo Mode"
    });

    setAsteroids([
      {
        id: "2023 AB1",
        name: "2023 AB1",
        diameter: 120,
        distance: 4.2,
        velocity: 15.3,
        hazardous: false,
        approach_date: "2025-01-15"
      }
    ]);

    setLastUpdate(new Date());
  };

  const refreshData = async () => {
    setLoading(true);
    await loadRealData();
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Live Space Data Dashboard</h2>
          <p className="text-slate-400">Real-time data from NASA APIs and space monitoring systems</p>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-slate-400">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </span>
          <Button 
            onClick={refreshData} 
            disabled={loading}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs defaultValue="apod" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 backdrop-blur-sm border border-slate-700">
          <TabsTrigger value="apod" className="data-[state=active]:bg-purple-600">
            <Image className="w-4 h-4 mr-2" />
            APOD
          </TabsTrigger>
          <TabsTrigger value="mars" className="data-[state=active]:bg-purple-600">
            <Thermometer className="w-4 h-4 mr-2" />
            Mars Weather
          </TabsTrigger>
          <TabsTrigger value="iss" className="data-[state=active]:bg-purple-600">
            <Satellite className="w-4 h-4 mr-2" />
            ISS Location
          </TabsTrigger>
          <TabsTrigger value="asteroids" className="data-[state=active]:bg-purple-600">
            <Zap className="w-4 h-4 mr-2" />
            Near Earth Objects
          </TabsTrigger>
        </TabsList>

        <TabsContent value="apod" className="mt-6">
          {apodData && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <Image className="w-5 h-5 text-purple-400" />
                  <span>Astronomy Picture of the Day</span>
                  <Badge variant="secondary" className="ml-auto">
                    {apodData.date}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src={apodData.url}
                    alt={apodData.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">{apodData.title}</h3>
                  <p className="text-slate-300 leading-relaxed">{apodData.explanation}</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="mars" className="mt-6">
          {marsWeather && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Thermometer className="w-5 h-5 text-red-400" />
                    <span>Mars Weather - Sol {marsWeather.sol}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-red-400">{marsWeather.temperature.high}°C</div>
                      <div className="text-sm text-slate-400">High Temperature</div>
                    </div>
                    <div className="p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-400">{marsWeather.temperature.low}°C</div>
                      <div className="text-sm text-slate-400">Low Temperature</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-300">Atmospheric Pressure:</span>
                      <span className="text-white">{marsWeather.pressure} Pa</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Wind Speed:</span>
                      <span className="text-white">{marsWeather.wind_speed} m/s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Season:</span>
                      <span className="text-white">{marsWeather.season}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-0">
                  <div className="aspect-square rounded-lg overflow-hidden">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1527826507412-72e447368aa1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJzJTIwcGxhbmV0JTIwc3VyZmFjZXxlbnwxfHx8fDE3NTk2NDI5MzR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt="Mars surface"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="iss" className="mt-6">
          {issLocation && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <MapPin className="w-5 h-5 text-green-400" />
                    <span>International Space Station</span>
                    <Badge variant="secondary" className="ml-auto bg-green-600">
                      Live
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-lg font-bold text-green-400">{issLocation.latitude.toFixed(2)}°</div>
                      <div className="text-sm text-slate-400">Latitude</div>
                    </div>
                    <div className="p-4 bg-slate-700/50 rounded-lg">
                      <div className="text-lg font-bold text-green-400">{issLocation.longitude.toFixed(2)}°</div>
                      <div className="text-sm text-slate-400">Longitude</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-300">Altitude:</span>
                      <span className="text-white">{issLocation.altitude} km</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Velocity:</span>
                      <span className="text-white">{issLocation.velocity.toLocaleString()} km/h</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Visibility:</span>
                      <span className="text-white">{issLocation.visibility}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-0">
                  <div className="aspect-square rounded-lg overflow-hidden">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1446776877081-d282a0f896e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMHN0YXRpb24lMjBvcmJpdCUyMGVhcnRofGVufDF8fHx8MTc1OTYxNDg2OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt="ISS in orbit"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="asteroids" className="mt-6">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-white">
                <Zap className="w-5 h-5 text-orange-400" />
                <span>Near Earth Objects (Asteroids)</span>
                <Badge variant="secondary" className="ml-auto">
                  Next 7 Days
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {asteroids.map((asteroid) => (
                  <div key={asteroid.id} className="p-4 bg-slate-700/50 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-semibold text-white">{asteroid.name}</h4>
                        <p className="text-sm text-slate-400">ID: {asteroid.id}</p>
                      </div>
                      {asteroid.hazardous && (
                        <Badge variant="destructive" className="bg-red-600">
                          Hazardous
                        </Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-slate-400">Diameter:</span>
                        <div className="text-white font-medium">{asteroid.diameter}m</div>
                      </div>
                      <div>
                        <span className="text-slate-400">Distance:</span>
                        <div className="text-white font-medium">{asteroid.distance} LD</div>
                      </div>
                      <div>
                        <span className="text-slate-400">Velocity:</span>
                        <div className="text-white font-medium">{asteroid.velocity} km/s</div>
                      </div>
                      <div>
                        <span className="text-slate-400">Approach:</span>
                        <div className="text-white font-medium">{asteroid.approach_date}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}